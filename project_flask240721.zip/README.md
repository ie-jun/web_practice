"회사 프로젝트용 FLASK 공부" 

"Jump to Flask" 
:https://wikidocs.net/book/4542

시작 - 2024/07/17 ~

Chapter 2-05 전 까지 진행(24/07/17)
Chapter 2-06 전 까지 진행(24/07/18)
Chapter 2-07 전 까지 진행(24/07/19)